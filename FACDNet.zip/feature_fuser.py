# feature_fuser.py
import torch
import torch.nn as nn

class CDFM(nn.Module):
    """Context-guided Difference Fusion Module (Direction-Aware)"""
    def __init__(self, in_channels):
        super(CDFM, self).__init__()
        
        # 🌟 创新升级：方向感知差值提取卷积
        self.dir_conv = nn.Sequential(
            nn.Conv2d(in_channels * 2, in_channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True)
        )
        
        # 门控：从 context 'c' 生成空间注意力 [B,1,H,W]
        self.gate_conv = nn.Conv2d(in_channels, 1, kernel_size=1)
        self.sigmoid = nn.Sigmoid()
        
        # 融合卷积
        self.fuse_conv = nn.Conv2d(in_channels * 2, in_channels, kernel_size=3, padding=1, bias=False)
        self.bn = nn.BatchNorm2d(in_channels)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, f1, f2, c):
        # 1. 计算双向差分以保留变化的物理方向性 (加入 ReLU 修复线性抵消漏洞)
        diff_forward = torch.relu(f1 - f2)  # 仅保留 F1 > F2 的特征 (消失)
        diff_reverse = torch.relu(f2 - f1)  # 仅保留 F2 > F1 的特征 (出现)

        diff_cat = torch.cat([diff_forward, diff_reverse], dim=1)  # [B, 2C, H, W]
        dir_diff = self.dir_conv(diff_cat)  # 降维至 [B, C, H, W]
        
        # 2. 上下文门控引导
        gate = self.sigmoid(self.gate_conv(c))          # [B, 1, H, W]
        refined_diff = dir_diff * gate                  # 抑制非变化区域的伪变化噪声
        
        # 3. 多源特征融合
        fused = torch.cat([refined_diff, c], dim=1)
        fused = self.fuse_conv(fused)
        fused = self.bn(fused)
        fused = self.relu(fused)
        return fused

class FeatureFuser(nn.Module):
    def __init__(self, in_channels_list):
        super(FeatureFuser, self).__init__()
        self.cdfm_modules = nn.ModuleList([
            CDFM(ch) for ch in in_channels_list
        ])

    def forward(self, features1, features2, t1_list, t2_list, c_list):
        fused_features = []
        for f1, f2, c, cdfm in zip(features1, features2, c_list, self.cdfm_modules):
            fused = cdfm(f1, f2, c)
            fused_features.append(fused)
        return fused_features