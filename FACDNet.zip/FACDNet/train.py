import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import cv2
import numpy as np
from tqdm import tqdm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import random

# 新增：torchmetrics（用于 per-class 指标）
from torchmetrics.classification import MulticlassPrecision, MulticlassRecall, MulticlassF1Score, MulticlassJaccardIndex

# 导入albumentations
import albumentations as A
from albumentations.pytorch import ToTensorV2

# 导入模型模块
from encoder import Encoder
from feature_interactor import FeatureInteractor
from feature_fuser import FeatureFuser
from decoder import Decoder
from clfca import CLFCA

def set_seed(seed=42):
    """固定所有的随机种子，确保实验完全可复现"""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)  # 如果使用多GPU
    
    # 针对 CuDNN 的设置，保证卷积运算的确定性
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


# -------------------------- 1. 数据集定义（不变）--------------------------
class LEVIRCDataset(Dataset):
    def __init__(self, data_root, split='train', transform=None):
        self.data_root = data_root
        self.split = split
        self.transform = transform

        self.img1_dir = os.path.join(data_root, f'{split}/A')
        self.img2_dir = os.path.join(data_root, f'{split}/B')
        self.label_dir = os.path.join(data_root, f'{split}/label')

        assert os.path.exists(self.img1_dir), f"A目录不存在：{self.img1_dir}"
        assert os.path.exists(self.img2_dir), f"B目录不存在：{self.img2_dir}"
        assert os.path.exists(self.label_dir), f"label目录不存在：{self.label_dir}"

        self.file_names = [f for f in os.listdir(self.img1_dir) if f.endswith('.png')]
        assert len(self.file_names) > 0, f"{split}集A目录无PNG文件：{self.img1_dir}"

        valid_files = []
        for f in self.file_names:
            b_path = os.path.join(self.img2_dir, f)
            label_path = os.path.join(self.label_dir, f)
            if os.path.exists(b_path) and os.path.exists(label_path):
                valid_files.append(f)
            else:
                print(f"警告：文件 {f} 缺少B图或label，已跳过")
        self.file_names = valid_files
        assert len(self.file_names) > 0, f"{split}集无有效文件组合"

    def __len__(self):
        return len(self.file_names)

    def __getitem__(self, idx):
        file_name = self.file_names[idx]
        img1_path = os.path.join(self.img1_dir, file_name)
        img2_path = os.path.join(self.img2_dir, file_name)
        label_path = os.path.join(self.label_dir, file_name)

        def safe_read(path, is_gray=False):
            flag = cv2.IMREAD_GRAYSCALE if is_gray else cv2.IMREAD_COLOR
            img = cv2.imread(path, flag)
            if img is None:
                print(f"警告：{path} 读取失败，使用空白图像替代")
                size = (512, 512)
                return np.zeros(size, dtype=np.uint8) if is_gray else np.zeros((*size, 3), dtype=np.uint8)
            return img

        img1 = safe_read(img1_path)[:, :, ::-1]
        img2 = safe_read(img2_path)[:, :, ::-1]
        label = safe_read(label_path, is_gray=True)

        img1 = cv2.resize(img1, (256, 256), interpolation=cv2.INTER_LINEAR)
        img2 = cv2.resize(img2, (256, 256), interpolation=cv2.INTER_LINEAR)
        label = cv2.resize(label, (256, 256), interpolation=cv2.INTER_NEAREST)
        label = (label > 127).astype(np.float32)

        if self.transform:
            augmented = self.transform(image=img1, image0=img2, mask=label)
            img1 = augmented['image']
            img2 = augmented['image0']
            label = augmented['mask']

        return img1, img2, label


# -------------------------- 2. 数据增强配置（不变）--------------------------
def get_transform(split):
    if split == 'train':
        return A.Compose([
            A.HorizontalFlip(p=0.5),
            A.VerticalFlip(p=0.3),
            A.RandomRotate90(p=0.5),
            A.ShiftScaleRotate(
                shift_limit=0.05,
                scale_limit=0.2,
                rotate_limit=0,
                p=0.3,
                border_mode=cv2.BORDER_CONSTANT
            ),
            A.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225],
                max_pixel_value=255.0
            ),
            ToTensorV2(),
        ], additional_targets={'image0': 'image'})

    elif split in ['val', 'test']:
        return A.Compose([
            A.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225],
                max_pixel_value=255.0
            ),
            ToTensorV2(),
        ], additional_targets={'image0': 'image'})


# -------------------------- 3. 使用 torchmetrics 的 per-class 指标计算 --------------------------
def compute_per_class_metrics(preds, labels, device):
    precision_metric = MulticlassPrecision(num_classes=2, average=None).to(device)
    recall_metric = MulticlassRecall(num_classes=2, average=None).to(device)
    f1_metric = MulticlassF1Score(num_classes=2, average=None).to(device)
    iou_metric = MulticlassJaccardIndex(num_classes=2, average=None).to(device)

    precision_metric.update(preds, labels)
    recall_metric.update(preds, labels)
    f1_metric.update(preds, labels)
    iou_metric.update(preds, labels)

    prec = precision_metric.compute()
    rec = recall_metric.compute()
    f1 = f1_metric.compute()
    iou = iou_metric.compute()

    return {
        'precision': prec,
        'recall': rec,
        'f1': f1,
        'iou': iou
    }


# -------------------------- 4. 🌟 替换：Focal + Dice 联合损失函数 --------------------------
class FocalDiceLoss(nn.Module):
    def __init__(self, alpha=0.75, gamma=2.0, focal_weight=0.5, dice_weight=0.5):
        """
        alpha: 正样本（变化类）的权重。设为 >0.5 可以提升 Recall。
        gamma: 困难样本聚焦参数。设为 2.0 强迫模型关注难识别的边界像素。
        """
        super(FocalDiceLoss, self).__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.focal_weight = focal_weight
        self.dice_weight = dice_weight

    def forward(self, pred, target):
        # 1. 为了防止 log(0) 导致梯度爆炸，对预测概率进行微小的限制
        pred = torch.clamp(pred, min=1e-6, max=1.0 - 1e-6)
        
        # 2. 计算 Focal Loss
        # target == 1 (变化的像素)
        loss_pos = -self.alpha * torch.pow((1.0 - pred), self.gamma) * target * torch.log(pred)
        # target == 0 (未变化的像素)
        loss_neg = -(1.0 - self.alpha) * torch.pow(pred, self.gamma) * (1.0 - target) * torch.log(1.0 - pred)
        
        focal_loss = (loss_pos + loss_neg).mean()
        
        # 3. 计算 Dice Loss
        smooth = 1e-5
        pred_flat = pred.view(-1)
        target_flat = target.view(-1)
        intersection = (pred_flat * target_flat).sum()
        dice_loss = 1 - ((2. * intersection + smooth) / 
                         (pred_flat.sum() + target_flat.sum() + smooth))
        
        # 4. 联合返回
        return self.focal_weight * focal_loss + self.dice_weight * dice_loss


# -------------------------- 5. 完整FACDNet模型 --------------------------
class FACDNet(nn.Module):
    def __init__(self):
        super(FACDNet, self).__init__()
        self.encoder = Encoder()
        self.interactor = FeatureInteractor([96, 192, 384, 768])
        
        self.clfca = CLFCA([96, 192, 384, 768])
        
        self.fuser = FeatureFuser([96, 192, 384, 768])
        self.decoder = Decoder([96, 192, 384, 768], num_classes=1)

    def forward(self, x1, x2):
        f1_list = self.encoder(x1)
        f2_list = self.encoder(x2)
        
        t1_list, t2_list, c_list = self.interactor(f1_list, f2_list)
        
        refined_c_list = self.clfca(c_list)
        
        fused_features = self.fuser(f1_list, f2_list, t1_list, t2_list, refined_c_list)
        
        output = self.decoder(fused_features)
        return output


# -------------------------- 6. 训练主函数 --------------------------
def train(config):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"===== 训练配置 =====")
    print(f"设备：{device}")
    print(f"数据集路径：{config['data_root']}")
    print(f"批次大小：{config['batch_size']}")
    print(f"学习率：{config['lr']}")
    print(f"训练轮次：{config['epochs']}")
    print(f"====================\n")

    print("加载数据集...")
    train_dataset = LEVIRCDataset(data_root=config['data_root'], split='train', transform=get_transform('train'))
    val_dataset = LEVIRCDataset(data_root=config['data_root'], split='val', transform=get_transform('val'))
    print(f"训练集样本数：{len(train_dataset)}")
    print(f"验证集样本数：{len(val_dataset)}")

    train_loader = DataLoader(train_dataset, batch_size=config['batch_size'], shuffle=True,
                              num_workers=config['num_workers'], pin_memory=True, drop_last=True)
    val_loader = DataLoader(val_dataset, batch_size=config['batch_size'], shuffle=False,
                            num_workers=config['num_workers'], pin_memory=True, drop_last=False)

    print("\n初始化模型...")
    model = FACDNet().to(device)
    
    # 🌟 实例化全新的 Focal-Dice 联合损失函数
    criterion = FocalDiceLoss(alpha=0.75, gamma=2.0, focal_weight=0.5, dice_weight=0.5)
    
    optimizer = optim.AdamW(model.parameters(), lr=config['lr'], weight_decay=1e-5)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=config['epochs'], eta_min=1e-6)

    best_val_changed_f1 = 0.0
    train_losses = []
    val_changed_f1_scores = []

    # 初始化 torchmetrics
    train_metrics = {
        'precision': MulticlassPrecision(num_classes=2, average=None).to(device),
        'recall': MulticlassRecall(num_classes=2, average=None).to(device),
        'f1': MulticlassF1Score(num_classes=2, average=None).to(device),
        'iou': MulticlassJaccardIndex(num_classes=2, average=None).to(device),
    }
    val_metrics = {
        'precision': MulticlassPrecision(num_classes=2, average=None).to(device),
        'recall': MulticlassRecall(num_classes=2, average=None).to(device),
        'f1': MulticlassF1Score(num_classes=2, average=None).to(device),
        'iou': MulticlassJaccardIndex(num_classes=2, average=None).to(device),
    }

    print("\n开始训练...")
    for epoch in range(config['epochs']):
        epoch_num = epoch + 1
        print(f"\n===== Epoch {epoch_num:3d}/{config['epochs']} =====")

        # -------------------------- 训练阶段 --------------------------
        model.train()
        train_loss = 0.0

        for metric in train_metrics.values():
            metric.reset()

        train_pbar = tqdm(train_loader, desc=f'Train Epoch {epoch_num}')
        for batch_idx, (img1, img2, label) in enumerate(train_pbar):
            img1, img2, label = img1.to(device), img2.to(device), label.to(device)

            if torch.rand(1) < 0.5:
                img1, img2 = img2, img1

            optimizer.zero_grad()
            output = model(img1, img2)
            loss = criterion(output.squeeze(1), label)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()

            train_loss += loss.item() * img1.size(0)

            pred_binary = (output > 0.5).long().view(-1)
            label_flat = label.long().view(-1)
            for metric in train_metrics.values():
                metric.update(pred_binary, label_flat)

            train_pbar.set_postfix({'batch_loss': round(loss.item(), 4)})

        avg_train_loss = train_loss / len(train_loader.dataset)
        train_losses.append(avg_train_loss)

        train_res = {name: metric.compute() for name, metric in train_metrics.items()}
        print("\n训练集指标：")
        print("+-----------+--------+-----------+--------+-------+-------+")
        print("|   Class   | Fscore | Precision | Recall |  IoU  |  Acc  |")
        print("+-----------+--------+-----------+--------+-------+-------+")
        class_names = ["unchanged", "changed"]
        for i, name in enumerate(class_names):
            f1_val = train_res['f1'][i].item() * 100
            prec_val = train_res['precision'][i].item() * 100
            rec_val = train_res['recall'][i].item() * 100
            iou_val = train_res['iou'][i].item() * 100
            acc_val = rec_val
            print(f"| {name:<9} | {f1_val:6.2f} | {prec_val:9.2f} | {rec_val:6.2f} | {iou_val:5.2f} | {acc_val:5.2f} |")
        print("+-----------+--------+-----------+--------+-------+-------+")

        # -------------------------- 验证阶段 --------------------------
        model.eval()
        val_loss = 0.0

        for metric in val_metrics.values():
            metric.reset()

        val_pbar = tqdm(val_loader, desc=f'Val Epoch {epoch_num}')
        with torch.no_grad():
            for img1, img2, label in val_pbar:
                img1, img2, label = img1.to(device), img2.to(device), label.to(device)
                output = model(img1, img2)
                loss = criterion(output.squeeze(1), label)
                val_loss += loss.item() * img1.size(0)

                pred_binary = (output > 0.5).long().view(-1)
                label_flat = label.long().view(-1)
                for metric in val_metrics.values():
                    metric.update(pred_binary, label_flat)

                val_pbar.set_postfix({'batch_loss': round(loss.item(), 4)})

        avg_val_loss = val_loss / len(val_loader.dataset)
        val_res = {name: metric.compute() for name, metric in val_metrics.items()}
        current_changed_f1 = val_res['f1'][1].item()
        val_changed_f1_scores.append(current_changed_f1 * 100)

        print("\n验证集指标：")
        print("+-----------+--------+-----------+--------+-------+-------+")
        print("|   Class   | Fscore | Precision | Recall |  IoU  |  Acc  |")
        print("+-----------+--------+-----------+--------+-------+-------+")
        for i, name in enumerate(class_names):
            f1_val = val_res['f1'][i].item() * 100
            prec_val = val_res['precision'][i].item() * 100
            rec_val = val_res['recall'][i].item() * 100
            iou_val = val_res['iou'][i].item() * 100
            acc_val = rec_val
            print(f"| {name:<9} | {f1_val:6.2f} | {prec_val:9.2f} | {rec_val:6.2f} | {iou_val:5.2f} | {acc_val:5.2f} |")
        print("+-----------+--------+-----------+--------+-------+-------+")

        # -------------------------- 模型保存 --------------------------
        # -------------------------- 模型保存 (新版本：最好与最新双备份) --------------------------
        os.makedirs(config['save_dir'], exist_ok=True)

        # 1. 保存当前最佳模型 (Best Model)
        if current_changed_f1 > best_val_changed_f1:
            best_val_changed_f1 = current_changed_f1
            best_save_path = os.path.join(config['save_dir'], 'best_model.pth')
            torch.save({
                'epoch': epoch_num,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
                'best_val_changed_f1': best_val_changed_f1,
                'train_losses': train_losses,
                'val_changed_f1_scores': val_changed_f1_scores
            }, best_save_path)
            print(f"✅ 保存最优模型（changed F1：{current_changed_f1*100:.2f}%）至：{best_save_path}")

        # 2. 每轮都保存/覆盖最新的模型 (Latest Model)
        # 把 optimizer 和 scheduler 的状态也存下来，方便以后做断点续传 (Resume Training)
        latest_save_path = os.path.join(config['save_dir'], 'latest_model.pth')
        torch.save({
            'epoch': epoch_num,
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'scheduler_state_dict': scheduler.state_dict(),
            'best_val_changed_f1': best_val_changed_f1,
            'train_losses': train_losses,
            'val_changed_f1_scores': val_changed_f1_scores
        }, latest_save_path)
        # 为了不刷屏，这里就不每次 print latest 模型的保存成功信息了

        scheduler.step()
        print(f"当前学习率：{scheduler.get_last_lr()[0]:.6f}")

    print(f"\n===== 训练完成！=====")
    print(f"最佳验证 changed F1：{best_val_changed_f1*100:.2f}%")

    # 绘制曲线
    plt.figure(figsize=(12, 4))
    plt.subplot(1, 2, 1)
    plt.plot(range(1, config['epochs']+1), train_losses, label='Train Loss', color='blue', linewidth=2)
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Training Loss Curve')
    plt.legend()
    plt.grid(alpha=0.3)

    plt.subplot(1, 2, 2)
    plt.plot(range(1, config['epochs']+1), val_changed_f1_scores, label='Val changed F1', color='red', linewidth=2)
    plt.xlabel('Epoch')
    plt.ylabel('F1 Score (%)')
    plt.title('Validation changed F1 Curve')
    plt.legend()
    plt.grid(alpha=0.3)

    curve_save_path = os.path.join(config['save_dir'], 'training_curves.png')
    plt.tight_layout()
    plt.savefig(curve_save_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"✅ 保存训练曲线至：{curve_save_path}")


# -------------------------- 7. 主函数 --------------------------
if __name__ == "__main__":
    # 🌟 关键：在程序启动的第一时间固定随机种子
    set_seed(42)
    config = {
        'data_root': '/hy-tmp/SHCD',
        'save_dir': '/hy-tmp/FACDNet/facdnet_checkpoints_shcd',
        'batch_size': 16,
        'lr': 1e-4,
        'epochs': 200,
        'num_workers': 2,
    }

    assert os.path.exists(config['data_root']), f"数据集路径不存在：{config['data_root']}"
    assert os.path.exists(os.path.join(config['data_root'], 'train/A')), f"缺少：{os.path.join(config['data_root'], 'train/A')}"
    assert os.path.exists(os.path.join(config['data_root'], 'val/A')), f"缺少：{os.path.join(config['data_root'], 'val/A')}"

    train(config)