# clfca.py
import torch
import torch.nn as nn
import torch.nn.functional as F


class CLFCA(nn.Module):
    """
    Cross-Layer Frequency Context Aggregator (跨层频域上下文聚合模块)
    作用：将深层低频全局语义，自顶向下注入到浅层高频边界特征中，净化空间门控信号。
    """

    def __init__(self, dims=[96, 192, 384, 768]):
        super(CLFCA, self).__init__()

        # 维度对齐模块：使用 1x1 卷积将深层的高维通道压缩至与浅层一致
        self.align_3_to_2 = nn.Sequential(
            nn.Conv2d(dims[3], dims[2], kernel_size=1, bias=False),
            nn.BatchNorm2d(dims[2]),
            nn.ReLU(inplace=True)
        )

        self.align_2_to_1 = nn.Sequential(
            nn.Conv2d(dims[2], dims[1], kernel_size=1, bias=False),
            nn.BatchNorm2d(dims[1]),
            nn.ReLU(inplace=True)
        )

        self.align_1_to_0 = nn.Sequential(
            nn.Conv2d(dims[1], dims[0], kernel_size=1, bias=False),
            nn.BatchNorm2d(dims[0]),
            nn.ReLU(inplace=True)
        )

    def forward(self, c_list):
        # 接收来自 WIB 的 4 个尺度的孤立上下文
        c0, c1, c2, c3 = c_list

        # --- 自顶向下的语义注入 (Top-Down Semantic Injection) ---

        # 1. Stage 4 引导 Stage 3 (768 -> 384)
        c3_aligned = self.align_3_to_2(c3)
        c3_up = F.interpolate(c3_aligned, size=c2.shape[2:], mode='bilinear', align_corners=False)
        c2_refined = c2 + c3_up  # 融合了最深层语义的中层上下文

        # 2. Stage 3 引导 Stage 2 (384 -> 192)
        c2_aligned = self.align_2_to_1(c2_refined)
        c2_up = F.interpolate(c2_aligned, size=c1.shape[2:], mode='bilinear', align_corners=False)
        c1_refined = c1 + c2_up  # 融合了语义的浅层上下文

        # 3. Stage 2 引导 Stage 1 (192 -> 96)
        c1_aligned = self.align_1_to_0(c1_refined)
        c1_up = F.interpolate(c1_aligned, size=c0.shape[2:], mode='bilinear', align_corners=False)
        c0_refined = c0 + c1_up  # 最底层、边界最锐利、且受全局语义保护的上下文

        # 返回净化并聚合后的多尺度上下文，随后将送入 CDFM 充当门控
        return [c0_refined, c1_refined, c2_refined, c3]