import torch
import torch.nn as nn
import torch.nn.functional as F


class DecoderBlock(nn.Module):
    def __init__(self, in_channels, skip_channels, out_channels):
        super(DecoderBlock, self).__init__()
        self.upconv = nn.ConvTranspose2d(in_channels, out_channels, kernel_size=2, stride=2)
        self.conv = nn.Sequential(
            nn.Conv2d(out_channels + skip_channels, out_channels, 3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, 3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x, skip):
        x = self.upconv(x)
        if x.shape[2:] != skip.shape[2:]:
            x = F.interpolate(x, size=skip.shape[2:], mode='bilinear', align_corners=False)
        x = torch.cat([x, skip], dim=1)
        return self.conv(x)


class Decoder(nn.Module):
    def __init__(self, in_channels_list, num_classes=1):
        super(Decoder, self).__init__()
        # Encoder channels: [96, 192, 384, 768]
        self.block1 = DecoderBlock(768, 384, 384)
        self.block2 = DecoderBlock(384, 192, 192)
        self.block3 = DecoderBlock(192, 96, 96)
        # Last block: x and x (both have channel = 96 after block3 output)
        self.block4 = DecoderBlock(96, 96, 48)  # skip_channels = 96 (since skip=x from previous output)
        self.final_conv = nn.Conv2d(48, num_classes, 1)

    def forward(self, fused_features):
        # fused_features: [96@128, 192@64, 384@32, 768@16]
        x = fused_features[3]  # 768

        x = self.block1(x, fused_features[2])  # skip: 384
        x = self.block2(x, fused_features[1])  # skip: 192
        x = self.block3(x, fused_features[0])  # skip: 96
        x = self.block4(x, x)                  # skip: x (96 channels)

        x = F.interpolate(x, size=(256, 256), mode='bilinear', align_corners=False)
        output = self.final_conv(x)
        return torch.sigmoid(output)