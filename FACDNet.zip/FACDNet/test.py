import os
import torch
import torch.nn as nn
import cv2
import numpy as np
from torch.utils.data import Dataset, DataLoader
from tqdm import tqdm
import random

# ========== 必需的第三方库 ==========
import albumentations as A
from albumentations.pytorch import ToTensorV2
from torchmetrics.classification import (
    MulticlassPrecision,
    MulticlassRecall,
    MulticlassF1Score,
    MulticlassJaccardIndex,
    MulticlassAccuracy
)

# ========== 导入模型模块 ==========
from encoder import Encoder
from feature_interactor import FeatureInteractor
from feature_fuser import FeatureFuser
from decoder import Decoder
from clfca import CLFCA  # 🌟 新增：导入跨层频域上下文聚合模块

def set_seed(seed=42):
    """固定所有的随机种子，确保实验完全可复现"""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)  # 如果使用多GPU
    
    # 针对 CuDNN 的设置，保证卷积运算的确定性
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


# -------------------------- 1. 模型定义（已与带 CLFCA 的 train.py 严格对齐）--------------------------
class FACDNet(nn.Module):
    def __init__(self):
        super(FACDNet, self).__init__()
        self.encoder = Encoder()
        self.interactor = FeatureInteractor([96, 192, 384, 768])
        
        # 🌟 新增：跨层聚合模块
        self.clfca = CLFCA([96, 192, 384, 768])
        
        self.fuser = FeatureFuser([96, 192, 384, 768])
        self.decoder = Decoder([96, 192, 384, 768], num_classes=1)

    def forward(self, x1, x2):
        f1_list = self.encoder(x1)
        f2_list = self.encoder(x2)
        
        # 1. 提取多尺度频域上下文
        t1_list, t2_list, c_list = self.interactor(f1_list, f2_list)
        
        # 2. 🌟 跨层语义与边界聚合
        refined_c_list = self.clfca(c_list)
        
        # 3. 🌟 使用净化后的上下文引导差值融合
        fused_features = self.fuser(f1_list, f2_list, t1_list, t2_list, refined_c_list)
        
        output = self.decoder(fused_features)  # 已含 sigmoid
        return output


# -------------------------- 2. 数据增强（与 train.py 的 val 完全一致）--------------------------
def get_transform():
    return A.Compose([
        A.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225],
            max_pixel_value=255.0
        ),
        ToTensorV2(),
    ], additional_targets={'image0': 'image'})


# -------------------------- 3. 测试数据集（使用 albumentations）--------------------------
class LEVIRCDTestDataset(Dataset):
    def __init__(self, data_root, transform=None):
        self.data_root = data_root
        self.transform = transform
        self.image_list = sorted(os.listdir(os.path.join(data_root, 'test', 'A')))

    def __len__(self):
        return len(self.image_list)

    def __getitem__(self, idx):
        name = self.image_list[idx]
        img1_path = os.path.join(self.data_root, 'test', 'A', name)
        img2_path = os.path.join(self.data_root, 'test', 'B', name)
        label_path = os.path.join(self.data_root, 'test', 'label', name)

        img1 = cv2.imread(img1_path)[:, :, ::-1]  # BGR → RGB
        img2 = cv2.imread(img2_path)[:, :, ::-1]
        label = cv2.imread(label_path, cv2.IMREAD_GRAYSCALE)

        if img1 is None or img2 is None or label is None:
            raise FileNotFoundError(f"图像读取失败: {name}")

        img1 = cv2.resize(img1, (256, 256), interpolation=cv2.INTER_LINEAR)
        img2 = cv2.resize(img2, (256, 256), interpolation=cv2.INTER_LINEAR)
        label = cv2.resize(label, (256, 256), interpolation=cv2.INTER_NEAREST)
        label = (label > 127).astype(np.float32)

        if self.transform:
            augmented = self.transform(image=img1, image0=img2, mask=label)
            img1 = augmented['image']
            img2 = augmented['image0']
            label = augmented['mask']

        return img1, img2, label, name


# -------------------------- 4. 配置 --------------------------
config = {
    'data_root': '/hy-tmp/SHCD',
    'checkpoint_path': '/hy-tmp/FACDNet/facdnet_checkpoints_shcd/latest_model.pth',
    'batch_size': 16,
    'num_workers': 2,
    'save_pred_dir': '/hy-tmp/FACDNet/test_predictions_shcd',
}

os.makedirs(config['save_pred_dir'], exist_ok=True)


# -------------------------- 5. 测试主函数 --------------------------
def test():
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


    THRESHOLD = 0.5

    # 加载模型
    model = FACDNet().to(device)
    checkpoint = torch.load(config['checkpoint_path'], map_location=device, weights_only=False)
    model.load_state_dict(checkpoint['model_state_dict'])
    model.eval()
    print(f"✅ 成功加载模型权重: {config['checkpoint_path']}")
    print(f"⚙️ 当前测试判定阈值 (Threshold): {THRESHOLD}")

    # 创建测试集（使用与 val 相同的 transform）
    test_dataset = LEVIRCDTestDataset(config['data_root'], transform=get_transform())
    test_loader = DataLoader(
        test_dataset,
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=config['num_workers'],
        pin_memory=True
    )
    print(f"🧪 测试集样本数: {len(test_dataset)}")
    print(f"💾 预测图将保存至: {config['save_pred_dir']}")

    # 初始化指标（per-class）
    metrics = {
        'precision': MulticlassPrecision(num_classes=2, average=None).to(device),
        'recall': MulticlassRecall(num_classes=2, average=None).to(device),
        'f1': MulticlassF1Score(num_classes=2, average=None).to(device),
        'iou': MulticlassJaccardIndex(num_classes=2, average=None).to(device),
        'acc': MulticlassAccuracy(num_classes=2, average=None).to(device),
    }

    for m in metrics.values():
        m.reset()

    with torch.no_grad():
        for img1, img2, label, names in tqdm(test_loader, desc="Testing"):
            img1, img2, label = img1.to(device), img2.to(device), label.to(device)

            # ⚠️ 关键：不再调用 torch.sigmoid！decoder 已经做了
            output = model(img1, img2)  # shape: (B, 1, H, W)

            # 二值化预测（应用自定义阈值）
            pred_binary = (output > THRESHOLD).long().view(-1)
            label_flat = label.long().view(-1)

            # 更新指标
            for metric in metrics.values():
                metric.update(pred_binary, label_flat)

            # 保存预测图（0 或 255，应用自定义阈值）
            pred_np = (output.squeeze(1).cpu().numpy() > THRESHOLD).astype(np.uint8)
            for i, name in enumerate(names):
                cv2.imwrite(os.path.join(config['save_pred_dir'], name), pred_np[i] * 255)

    # 计算最终结果
    res = {name: metric.compute() for name, metric in metrics.items()}

    # 打印表格
    print("\n+-----------+--------+-----------+--------+-------+-------+")
    print("|   Class   | Fscore | Precision | Recall |  IoU  |  Acc  |")
    print("+-----------+--------+-----------+--------+-------+-------+")
    class_names = ["unchanged", "changed"]
    for i, name in enumerate(class_names):
        f1_val = res['f1'][i].item() * 100
        prec_val = res['precision'][i].item() * 100
        rec_val = res['recall'][i].item() * 100
        iou_val = res['iou'][i].item() * 100
        acc_val = res['acc'][i].item() * 100
        print(f"| {name:<9} | {f1_val:6.2f} | {prec_val:9.2f} | {rec_val:6.2f} | {iou_val:5.2f} | {acc_val:5.2f} |")
    print("+-----------+--------+-----------+--------+-------+-------+")

    # 全局指标
    mFscore = res['f1'].mean().item() * 100
    mPrecision = res['precision'].mean().item() * 100
    mRecall = res['recall'].mean().item() * 100
    mIoU = res['iou'].mean().item() * 100
    mAcc = res['acc'].mean().item() * 100

    # aAcc (overall pixel accuracy)
    total_acc_metric = MulticlassAccuracy(num_classes=2, average='micro').to(device)
    total_acc_metric.reset()
    with torch.no_grad():
        for img1, img2, label, _ in test_loader:
            img1, img2, label = img1.to(device), img2.to(device), label.to(device)
            output = model(img1, img2)
            # 全局准确率计算同样应用自定义阈值
            pred = (output > THRESHOLD).long()
            total_acc_metric.update(pred.view(-1), label.long().view(-1))
    aAcc = total_acc_metric.compute().item() * 100

    print(f"\nINFO - Iter(test) [{len(test_dataset)}/{len(test_dataset)}]")
    print(f"aAcc: {aAcc:6.2f}  mFscore: {mFscore:6.2f}  mPrecision: {mPrecision:6.2f}  "
          f"mRecall: {mRecall:6.2f}  mIoU: {mIoU:6.2f}  mAcc: {mAcc:6.2f}")

    print(f"\n✅ 所有预测图已保存到: {config['save_pred_dir']}")


# -------------------------- 6. 主入口 --------------------------
if __name__ == '__main__':
    set_seed(42)
    test()