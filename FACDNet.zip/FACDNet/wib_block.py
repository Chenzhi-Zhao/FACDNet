# wib_block.py
import torch
import torch.nn as nn
from wavelet_utils import dwt, iwt  # 确保已实现纯PyTorch版本


class ChannelAttention(nn.Module):
    """通道注意力模块 (用于低频全局语义)"""
    def __init__(self, in_channels, reduction=16):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.fc = nn.Sequential(
            nn.Conv2d(in_channels, in_channels // reduction, 1, bias=False),
            nn.ReLU(),
            nn.Conv2d(in_channels // reduction, in_channels, 1, bias=False)
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc(self.avg_pool(x))
        max_out = self.fc(self.max_pool(x))
        out = avg_out + max_out
        return self.sigmoid(out) * x


class SpatialAttention(nn.Module):
    """新增：空间注意力模块 (专为高频边缘纹理特征设计)"""
    def __init__(self, kernel_size=7):
        super().__init__()
        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1
        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        # 在通道维度上求平均值和最大值，突出空间位置的显著性响应
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        scale = torch.cat([avg_out, max_out], dim=1)
        scale = self.conv1(scale)
        return x * self.sigmoid(scale)


class WaveletInteractionBlock(nn.Module):
    """
    统一的波-注意力交互模块 (采用异构注意力机制强化创新)
    """
    def __init__(self, in_channels):
        super().__init__()
        self.in_channels = in_channels

        # 频段融合：拼接 + 1x1卷积
        self.fuse_ll = nn.Sequential(nn.Conv2d(in_channels * 2, in_channels, kernel_size=1), nn.ReLU())
        self.fuse_lh = nn.Sequential(nn.Conv2d(in_channels * 2, in_channels, kernel_size=1), nn.ReLU())
        self.fuse_hl = nn.Sequential(nn.Conv2d(in_channels * 2, in_channels, kernel_size=1), nn.ReLU())
        self.fuse_hh = nn.Sequential(nn.Conv2d(in_channels * 2, in_channels, kernel_size=1), nn.ReLU())

        # 🌟 核心创新：针对高低频物理特性的异构注意力
        self.att_ll = ChannelAttention(in_channels)  # LL 包含宏观语义，使用通道注意力
        self.att_lh = SpatialAttention()             # LH 包含水平边缘，使用空间注意力
        self.att_hl = SpatialAttention()             # HL 包含垂直边缘，使用空间注意力
        self.att_hh = SpatialAttention()             # HH 包含对角边缘，使用空间注意力

    def forward(self, f1, f2):
        # 1. 小波分解
        LL1, LH1, HL1, HH1 = dwt(f1)
        LL2, LH2, HL2, HH2 = dwt(f2)

        # 2. 频段内融合
        LL_fused = self.fuse_ll(torch.cat([LL1, LL2], dim=1))
        LH_fused = self.fuse_lh(torch.cat([LH1, LH2], dim=1))
        HL_fused = self.fuse_hl(torch.cat([HL1, HL2], dim=1))
        HH_fused = self.fuse_hh(torch.cat([HH1, HH2], dim=1))

        # 3. 🌟 异构注意力增强 (Heterogeneous Attention)
        LL_att = self.att_ll(LL_fused)
        LH_att = self.att_lh(LH_fused)
        HL_att = self.att_hl(HL_fused)
        HH_att = self.att_hh(HH_fused)

        # 4. 逆变换重构
        c = iwt(LL_att, LH_att, HL_att, HH_att)

        return c, c, c