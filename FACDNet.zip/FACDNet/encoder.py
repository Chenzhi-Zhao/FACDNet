import torch
import torch.nn as nn
from torchvision.models import convnext_small

class Encoder(nn.Module):
    def __init__(self):
        super(Encoder, self).__init__()
        # 加载预训练 ConvNeXt-Small
        convnext = convnext_small(weights='IMAGENET1K_V1')

        # 按照原始 Tiny 的方式分组：每两个模块组成一个 stage
        self.stage1 = nn.Sequential(convnext.features[0], convnext.features[1])  # 96 @ 128
        self.stage2 = nn.Sequential(convnext.features[2], convnext.features[3])  # 192 @ 64
        self.stage3 = nn.Sequential(convnext.features[4], convnext.features[5])  # 384 @ 32
        self.stage4 = nn.Sequential(convnext.features[6], convnext.features[7])  # 768 @ 16

    def forward(self, x):
        # x: (B, 3, 512, 512)
        feat1 = self.stage1(x)   # (B, 96, 128, 128)
        feat2 = self.stage2(feat1)  # (B, 192, 64, 64)
        feat3 = self.stage3(feat2)  # (B, 384, 32, 32)
        feat4 = self.stage4(feat3)  # (B, 768, 16, 16)

        return [feat1, feat2, feat3, feat4]