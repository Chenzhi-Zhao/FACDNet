# feature_interactor.py (完全替换版)
import torch
import torch.nn as nn
from wib_block import WaveletInteractionBlock  # <-- 导入新模块


class FeatureInteractor(nn.Module):
    def __init__(self, dims=[96, 192, 384, 768]):
        super(FeatureInteractor, self).__init__()
        self.dims = dims

        # --- 关键修改：所有尺度都使用统一的 WIB 模块 ---
        self.wib_0 = WaveletInteractionBlock(dims[0])  # stage1
        self.wib_1 = WaveletInteractionBlock(dims[1])  # stage2
        self.wib_2 = WaveletInteractionBlock(dims[2])  # stage3
        self.wib_3 = WaveletInteractionBlock(dims[3])  # stage4

    def forward(self, f1_list, f2_list):
        t1_list, t2_list, c_list = [], [], []

        for i in range(len(f1_list)):
            f1, f2 = f1_list[i], f2_list[i]

            # 所有层级都使用 WIB
            if i == 0:
                t1, t2, c = self.wib_0(f1, f2)
            elif i == 1:
                t1, t2, c = self.wib_1(f1, f2)
            elif i == 2:
                t1, t2, c = self.wib_2(f1, f2)
            else:  # i == 3
                t1, t2, c = self.wib_3(f1, f2)

            t1_list.append(t1)
            t2_list.append(t2)
            c_list.append(c)

        return t1_list, t2_list, c_list