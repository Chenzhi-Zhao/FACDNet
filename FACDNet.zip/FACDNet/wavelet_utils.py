# wavelet_utils.py （完整替换为以下内容）

import torch
import torch.nn as nn
import torch.nn.functional as F


def dwt(x):
    """Haar DWT using conv2d"""
    B, C, H, W = x.shape

    # Pad if odd
    if H % 2 == 1:
        x = F.pad(x, (0, 0, 0, 1), mode='reflect')
    if W % 2 == 1:
        x = F.pad(x, (0, 1, 0, 0), mode='reflect')

    # Reshape to group pixels into 2x2 blocks
    x = x.view(B, C, H // 2, 2, W // 2, 2)

    # Apply Haar transform on 2x2 blocks
    LL = (x[:, :, :, 0, :, 0] + x[:, :, :, 0, :, 1] + x[:, :, :, 1, :, 0] + x[:, :, :, 1, :, 1]) / 2.0
    LH = (x[:, :, :, 0, :, 0] + x[:, :, :, 0, :, 1] - x[:, :, :, 1, :, 0] - x[:, :, :, 1, :, 1]) / 2.0
    HL = (x[:, :, :, 0, :, 0] - x[:, :, :, 0, :, 1] + x[:, :, :, 1, :, 0] - x[:, :, :, 1, :, 1]) / 2.0
    HH = (x[:, :, :, 0, :, 0] - x[:, :, :, 0, :, 1] - x[:, :, :, 1, :, 0] + x[:, :, :, 1, :, 1]) / 2.0

    return LL, LH, HL, HH


def iwt(LL, LH, HL, HH):
    """Inverse Haar DWT"""
    B, C, H, W = LL.shape

    # Reconstruct 2x2 blocks
    x00 = (LL + LH + HL + HH) / 2.0
    x01 = (LL + LH - HL - HH) / 2.0
    x10 = (LL - LH + HL - HH) / 2.0
    x11 = (LL - LH - HL + HH) / 2.0

    # Stack into [B, C, H, W, 2, 2]
    x = torch.stack([torch.stack([x00, x01], dim=-1),
                     torch.stack([x10, x11], dim=-1)], dim=-2)

    # Reshape back to [B, C, 2H, 2W]
    x = x.view(B, C, 2 * H, 2 * W)

    return x